import starfyre

from .counter import Counter
from .display import Display
from .component_state_example import ComponentStateExample


def main():
    counter = Counter()
    display = Display()
    component_state_example = ComponentStateExample()
    print(component_state_example)
    counter.children.append(display)
    counter.children.append(component_state_example)
    # display.children.append(counter)
    print("bccc")
    # print(display)
    starfyre.render(counter, starfyre.js.document.getElementById("root"))
