from starfyre import create_signal

[get_state, set_state] = create_signal(0)

