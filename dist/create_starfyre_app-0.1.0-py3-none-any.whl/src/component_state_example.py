from starfyre import create_component, create_signal

[get_component_state, set_state] = create_signal(0)


def updateCounter(component, *args):
    set_state(get_component_state(component) + 1)


def ComponentStateExample():
    return create_component(
        """<div >This is the component state {get_component_state} <button onClick={updateCount}>Click Here to increment</button> </div>""",
        {"updateCount": updateCounter},
        state={"get_component_state": get_component_state},
    )
